(function () {
  const data = window.bizLensData || {};
  const fmt = value => '₹' + Number(value).toLocaleString('en-IN', {maximumFractionDigits: 0});
  const gridColor = '#edf0f6';
  const tickColor = '#8b94a7';

  const monthlyCanvas = document.getElementById('monthlyChart');
  if (monthlyCanvas) {
    new Chart(monthlyCanvas, {
      type: 'line',
      data: {
        labels: data.monthLabels || [],
        datasets: [{
          label: 'Revenue',
          data: data.monthValues || [],
          borderColor: '#566ce8',
          backgroundColor: 'rgba(86,108,232,.12)',
          borderWidth: 3,
          pointRadius: 3,
          pointBackgroundColor: '#566ce8',
          fill: true,
          tension: .35
        }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: context => fmt(context.raw) } } },
        scales: {
          x: { grid: { display: false }, ticks: { color: tickColor, maxRotation: 0, autoSkip: true } },
          y: { beginAtZero: true, grid: { color: gridColor }, ticks: { color: tickColor, callback: value => value >= 1000 ? '₹' + (value / 1000).toFixed(0) + 'k' : '₹' + value } }
        }
      }
    });
  }

  const categoryCanvas = document.getElementById('categoryChart');
  if (categoryCanvas) {
    new Chart(categoryCanvas, {
      type: 'doughnut',
      data: {
        labels: data.categoryLabels || [],
        datasets: [{ data: data.categoryValues || [], backgroundColor: ['#566ce8','#24b68b','#f3a64a','#9a77e8','#50b5d8','#f07891'], borderWidth: 3, borderColor: '#fff', hoverOffset: 5 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '67%',
        plugins: { legend: { position: 'bottom', labels: { color: tickColor, boxWidth: 9, boxHeight: 9, padding: 14, font: { size: 10 } } },
          tooltip: { callbacks: { label: context => context.label + ': ' + fmt(context.raw) } } }
      }
    });
  }

  const regionCanvas = document.getElementById('regionChart');
  if (regionCanvas) {
    new Chart(regionCanvas, {
      type: 'bar',
      data: {
        labels: data.regionLabels || [],
        datasets: [{ label: 'Revenue', data: data.regionValues || [], backgroundColor: '#6f82ed', borderRadius: 5, maxBarThickness: 34 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: context => fmt(context.raw) } } },
        scales: {
          x: { grid: { display: false }, ticks: { color: tickColor } },
          y: { beginAtZero: true, grid: { color: gridColor }, ticks: { color: tickColor, callback: value => value >= 1000 ? '₹' + (value / 1000).toFixed(0) + 'k' : '₹' + value } }
        }
      }
    });
  }
})();
